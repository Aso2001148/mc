<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://kit.fontawesome.com/3239b2a89b.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://unpkg.com/destyle.css@1.0.5/destyle.css">
    <link rel="stylesheet" href="../css/index_style_main.css">

    <!-- グーグルフォント -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=M+PLUS+Rounded+1c:wght@100&display=swap" rel="stylesheet">
</head>
<body>
<section id="top">
    <div class="form">
        <p class="form1">Survay</p>
        <a href="#"><p class="btn1"><i class="fab fa-twitter"></i>Twitterでログイン</p></a>
        <a href="#"><p class="btn2"><i class="fab fa-facebook-f"></i>Facebookでログイン</p></a>
        <center>
            <p class="or">または</p>
            <p>ゲストでログイン</p>
        </center>
    </div>
    <div class="img">
    </div>
</section>
</body>
</html>