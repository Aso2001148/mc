<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>test</title>
    <link rel="stylesheet" href="../css/main_style.css">
    <link rel="stylesheet" href="../css/create_prof.css">
</head>
<body>
<header>
    <div class="head_main">
        <a href="../backup_210714/home.php" class="head_link">
            <img src="../img/Survay_logo.jpg" class="head_img">
            <span class="head_txtstyle">Survay</span>
        </a>
    </div>
    <div class="head_name">プロフ作成</div>
</header>
<div class="main">
    <div class="title_div">
        <span class="main_title">プロフィール作成</span>
        <span class="sub_title">※後から変更できます</span>
    </div>
    <form>
        <div class="form">　
            <div class="txt_div">
                <span class="prof_icon"><ion-icon name="accessibility-outline"></ion-icon></span>
                <span class="prof_txt">年齢</span>
            </div>
            <div class="old_div">
                <ul class="old_ul">
                    <li>
                        <input type="radio" name="old" value="old_10" id="before10">
                        <label for="before10">10代</label>
                    </li>
                    <li>
                        <input type="radio" name="old" value="old_20" id="after10">
                        <label for="after10">20代</label>
                    </li>
                    <li>
                        <input type="radio" name="old" value="old_30" id="before20">
                        <label for="before20">30代</label>
                    </li>
                    <li>
                        <input type="radio" name="old" value="old_40" id="after20">
                        <label for="after20">40代</label>
                    </li>
                    <li>
                        <input type="radio" name="old" value="old_50" id="before30">
                        <label for="before30">50代</label>
                    </li>
                    <li>
                        <input type="radio" name="old" value="after60" id="after60">
                        <label for="after60">60歳以上</label>
                    </li>
                </ul>
            </div>
            <div class="gender">
                <div class="txt_div">
                    <span class="prof_icon"><ion-icon name="male-female-outline"></ion-icon></span>
                    <span class="prof_txt">性別</span>
                </div>
                <ul class="gender_ul">
                    <li>
                        <input type="radio" name="gender" value="man" id="man">
                        <label for="man">男性</label>
                    </li>
                    <li>
                        <input type="radio" name="gender" value="woman" id="woman">
                        <label for="woman">女性</label>
                    </li>
                    <li>
                        <input type="radio" name="gender" value="other" id="othergender">
                        <label for="othergender">その他</label>
                    </li>
                </ul>
            </div>
            <div class="blood">
                <div class="txt_div">
                    <span class="prof_icon"><ion-icon name="water-outline"></ion-icon></span>
                    <span class="prof_txt">血液型</span>
                </div>
                <ul class="blood_ul">
                    <li>
                        <input type="radio" name="blood" value="blood_A" id="A">
                        <label for="A">A型</label>
                    </li>
                    <li>
                        <input type="radio" name="blood" value="blood_B" id="B">
                        <label for="B">B型</label>
                    </li>
                    <li>
                        <input type="radio" name="blood" value="blood_AB" id="AB">
                        <label for="AB">AB型</label>
                    </li>
                    <li>
                        <input type="radio" name="blood" value="blood_O" id="O">
                        <label for="O">O型</label>
                    </li>
                </ul>
            </div>
            <div class="job">
                <div class="txt_div">
                    <span class="prof_icon"><ion-icon name="bag-remove-outline"></ion-icon></span>
                    <span class="prof_txt">職業</span>
                </div>
                <ul class="job_ul">
                    <li>
                        <input type="radio" name="job" value="none" id="none">
                        <label for="none">働いてない(学生 主婦・主婦 その他)</label>
                    </li>
                    <li>
                        <input type="radio" name="job" value="free" id="free">
                        <label for="free">フリーター</label>
                    </li>
                    <li>
                        <input type="radio" name="job" value="service" id="service">
                        <label for="service">サービス業</label>
                    </li>
                    <li>
                        <input type="radio" name="job" value="IT" id="IT">
                        <label for="IT">IT系</label>
                    </li>
                    <li>
                        <input type="radio" name="job" value="medic" id="medic">
                        <label for="medic">医療・福祉系</label>
                    </li>
                    <li>
                        <input type="radio" name="job" value="teach" id="teach">
                        <label for="teach">教育</label>
                    </li>
                    <li>
                        <input type="radio" name="job" value="shipping" id="shipping">
                        <label for="shipping">運送業</label>
                    </li>
                    <li>
                        <input type="radio" name="job" value="const" id="const">
                        <label for="const">建設業</label>
                    </li>
                    <li>
                        <input type="radio" name="job" value="create" id="create">
                        <label for="create">製造業</label>
                    </li>
                    <li>
                        <input type="radio" name="job" value="other" id="otherjob">
                        <label for="otherjob">その他</label>
                    </li>
                </ul>
            </div>
            <div class="submit">
                <input type="submit" value="決定！" class="submit_btn">
            </div>
        </div>
    </form>
</div>

<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>
</html>